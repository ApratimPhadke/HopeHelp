const translations = {
    en: {
        siteTitle: "HopeConnect",
        navGuidelines: "Guidelines",
        navHome: "Home",
        navDashboard: "Dashboard",
        navShelter: "Shelter Locator",
        navAlerts: "Emergency Alerts",
        navVolunteer: "Volunteer Signup",
        navContact: "Contact",
        btnSignup: "Sign Up",
    },
    hi: {
        siteTitle: "होपकनेक्ट",
        navGuidelines: "दिशानिर्देश",
        navHome: "होम",
        navDashboard: "डैशबोर्ड",
        navShelter: "आश्रय खोजक",
        navAlerts: "आपातकालीन अलर्ट",
        navVolunteer: "स्वयंसेवक साइनअप",
        navContact: "संपर्क करें",
        btnSignup: "साइन अप करें",
    },
    mr: {
        siteTitle: "होपकनेक्ट",
        navGuidelines: "मार्गदर्शक तत्त्वे",
        navHome: "मुख्यपृष्ठ",
        navDashboard: "डॅशबोर्ड",
        navShelter: "निवारा शोधक",
        navAlerts: "आपत्कालीन सूचना",
        navVolunteer: "स्वयंसेवक नोंदणी",
        navContact: "संपर्क",
        btnSignup: "साइन अप करा",
    }
};

document.getElementById("languageSelect").addEventListener("change", function () {
    let selectedLang = this.value;
    let previousLang = document.getElementById("currentLang").innerText;
    let alertBox = document.getElementById("languageAlert");
    let currentLangText = selectedLang === "hi" ? "Hindi" : selectedLang === "mr" ? "Marathi" : "English";

   
    document.getElementById("previousLang").innerText = previousLang;
    document.getElementById("currentLang").innerText = currentLangText;

    
    alertBox.classList.remove("d-none");

    
    let translation = translations[selectedLang];
    document.getElementById("siteTitle").innerText = translation.siteTitle;
    document.getElementById("navGuidelines").innerText = translation.navGuidelines;
    document.getElementById("navHome").innerText = translation.navHome;
    document.getElementById("navDashboard").innerText = translation.navDashboard;
    document.getElementById("navShelter").innerText = translation.navShelter;
    document.getElementById("navAlerts").innerText = translation.navAlerts;
    document.getElementById("navVolunteer").innerText = translation.navVolunteer;
    document.getElementById("navContact").innerText = translation.navContact;
    document.getElementById("btnSignup").innerText = translation.btnSignup;

    setTimeout(function () {
        alertBox.classList.add("d-none");
    }, 3000);
});
document.getElementById("navGuidelines").addEventListener("click", function() {
    showSection("navGuidelines");
})
document.getElementById("navHome").addEventListener("click", function() {
    showSection("homeSection");
});
document.getElementById("navDashboard").addEventListener("click", function() {
    showSection("dashboardSection");
});
document.getElementById("navShelter").addEventListener("click", function() {
    showSection("shelterSection");
});
document.getElementById("navAlerts").addEventListener("click", function() {
    showSection("alertsSection");
});
document.getElementById("navVolunteer").addEventListener("click", function() {
    showSection("volunteerSection");
});
document.getElementById("navContact").addEventListener("click", function() {
    showSection("contactSection");
});

function showSection(sectionId) {
   
    var sections = document.querySelectorAll(".section");
    sections.forEach(function(section) {
        section.style.display = "none";
    });

    
    document.getElementById(sectionId).style.display = "block";
}
