document.getElementById("navGuidelines").addEventListener("click", function() {
    showSection("navGuidelines");
})
document.getElementById("navHome").addEventListener("click", function() {
    showSection("homeSection");
});
document.getElementById("navDashboard").addEventListener("click", function() {
    showSection("dashboardSection");
});
document.getElementById("navShelter").addEventListener("click", function() {
    showSection("shelterSection");
});
document.getElementById("navAlerts").addEventListener("click", function() {
    showSection("alertsSection");
});
document.getElementById("navVolunteer").addEventListener("click", function() {
    showSection("volunteerSection");
});
document.getElementById("navContact").addEventListener("click", function() {
    showSection("contactSection");
});

function showSection(sectionId) {
   
    var sections = document.querySelectorAll(".section");
    sections.forEach(function(section) {
        section.style.display = "none";
    });

    
    document.getElementById(sectionId).style.display = "block";
}
